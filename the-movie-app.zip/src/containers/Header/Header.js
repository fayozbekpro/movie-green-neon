import {Link} from "react-router-dom";
import "./Header.scss";
import {BiMenu, BiSearch, BiLinkExternal} from "react-icons/bi";
import {AiOutlineClose} from "react-icons/ai";
import {useMemo, useState} from "react";
import SmallSearchCard from "../../components/SmallSearchCard/Card";
import axios from "axios";
const Header = () => {
    const [nav,
        setnav] = useState(false);
    const [c,
        setc] = useState("nav");
    const [searchval,
        setSearch] = useState("");
    const [searched,
        setSearched] = useState(undefined);
    const [changed,
        changeOption] = useState("movies");
    useMemo(async() => {
        axios
            .get(changed === "movies"
                ? "https://api.themoviedb.org/3/search/movie/"
                : "https://api.themoviedb.org/3/search/person/", {
                params: {
                    api_key: "6643bf493a4ee7747d5160e845000b20",
                    query: searchval
                }
            })
            .then(function (response) {
                if (!response.data.results[0]) {
                    setSearched(undefined);
                } else {
                    setSearched(response.data.results);
                }
            })
            .catch((e) => {
                console.log(e);
                setSearched(undefined);
            });
}, [searchval, changed]);

    const saveval = (event) => {
        setSearch(event.target.value);
    };

    return (
        <div className="header">
            <nav>
                <div className="logo">
                    <Link to="/">
                        Prog
                        <span className="root-secondary">ress</span>
                    </Link>
                </div>
                <div className="search-bar">
                    <div className="input">
                        <BiSearch/>
                        <input
                            type="text"
                            onChange={(event) => {
                            saveval(event);
                        }}
                            placeholder="PROGRESS"
                            value={searchval}/>
                    </div>
                    <div className="search-results">
                    {!searched ? (
                        ""
                        ) : (
                        <>
                           <div className="select-type">
                              <select
                              name="select"
                              onChange={(e) => {
                                 changeOption(e.target.value);
                              }}
                              id="slc"
                              >
                              <option value="movies">Movies</option>
                              <option value="actors">Actors</option>
                              </select>
                           </div>
                           {searched.slice(0, 5).map((v, key) => (
                              <a
                              href={window.location.origin + (changed === "movies" ? "/movie/" : "/person/") + v.id}
                              className="blank"
                              >
                                 <SmallSearchCard
                                    img={(changed === "movies" ? v.poster_path : v.profile_path)}
                                    title={(changed === "movies" ? v.title : v.name)}
                                    key={key}
                                 />
                              </a>
                           ))}
                           <div className="link">
                              <a
                              href={
                              window.location.origin + "/search/" + changed + "/" + searchval
                              }>                              
                                 <BiLinkExternal /> Show All
                              </a>
                           </div>
                        </>
                     )}
                    </div>
                    <div className="search-results-top"></div>
                </div>
                <div className={c} id="nav">
                    <Link
                        to="/"
                        className={window.location.pathname === "/"
                        ? "active-link"
                        : ""}
                        onClick={() => {
                        setnav(false);
                        setc("nav");
                    }}>
                        Home
                    </Link>
                    <Link
                        to="/populars"
                        className={window.location.pathname === "/populars"
                        ? "active-link"
                        : ""}
                        onClick={() => {
                        setnav(false);
                        setc("nav");
                    }}>
                        Most Popular
                    </Link>
                    {/* <Link
                        to="/search"
                        className={window.location.pathname === "/search"
                        ? "active-link"
                        : ""}
                        onClick={() => {
                        setnav(false);
                        setc("nav");
                    }}>
                        search
                    </Link> */}
                </div>
                <div
                    className="nav-toggle"
                    onClick={() => {
                    setc(!nav
                        ? "nav open-nav"
                        : "nav");
                    setnav(!nav);
                }}>
                    {!nav
                        ? <BiMenu/>
                        : <AiOutlineClose/>}
                </div>
            </nav>
        </div>
    );
};

export default Header;
