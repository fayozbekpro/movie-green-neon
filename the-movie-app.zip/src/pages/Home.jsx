import React, { useCallback, useEffect, useMemo, useReducer } from "react";
import "../assets/styles/Home.scss";
import "react-responsive-carousel/lib/styles/carousel.min.css";
import axios from "axios";
import Carousel from "../components/Carousel/Carousel";
import SmallSearchCard from "../components/SmallSearchCard/Card";
import MainRecommendMovies from "../components/MainRecommendMovies/Movies";
import Slider from "../components/Slider/Slider";
const reducer = (state, action) => {
  switch (action.type) {
    case "load": {
      return {
        ...state,
        result: action.payload,
      };
    }

    case "load2": {
      return {
        ...state,
        result2: action.payload,
      };
    }
    case "load3": {
      return {
        ...state,
        result3: action.payload,
      };
    }
    case "no": {
      return {
        ...state,
        ok: "no",
      };
    }
    case "yes": {
      return {
        ...state,
        ok: "yes",
      };
    }
    default: {
      return state;
    }
  }
};



export default function Home() {
  const [state, dispatch] = useReducer(reducer, [{recc: false,}]);
  useEffect(() => {
    axios
      .get("https://api.themoviedb.org/3/movie/popular", {
        params: {
          api_key: "6643bf493a4ee7747d5160e845000b20",
          language: "en-US",
        },
      })
      .then(function (response) {
        if (response.status !== 200) {
          console.log(response, "AAAA");
          dispatch({ type: "no" });
        } else {
          dispatch({ type: "yes" });
          dispatch({ type: "load", payload: response.data.results });
        }
      })
      .catch((e) => {
        console.log(e, "log");
      });
  }, []);

  useEffect(() => {
    axios
      .get("https://api.themoviedb.org/3/movie/top_rated", {
        params: {
          api_key: "6643bf493a4ee7747d5160e845000b20",
        },
      })
      .then(function (response) {
        if (response.status !== 200) {
          console.log(response, "AAAA");
          dispatch({ type: "no" });
        } else {
          dispatch({ type: "yes" });
          dispatch({ type: "load2", payload: response.data.results });
          console.log(response, "load2");
        }
      })
      .catch((e) => {
        console.log(e, "log");
      });
  }, []);


  useEffect(() => {
    axios
      .get("https://api.themoviedb.org/3/person/popular", {
        params: {
          api_key: "6643bf493a4ee7747d5160e845000b20",
        },
      })
      .then(function (response) {
        if (response.status !== 200) {
          console.log(response, "AAAA");
          dispatch({ type: "no" });
        } else {
          dispatch({ type: "yes" });
          dispatch({ type: "load3", payload: response.data.results });
          console.log(response, "load2");
        }
      })
      .catch((e) => {
        console.log(e, "log");
      });
  }, []);

    
  return (
    <>
      <main>
        <div
          className="main-carousel"
        >
          <Carousel>
            {!state.result ? "<div></div>" : state.result.slice(0, 12).map((val, key) => (
              <>
                <div>
                  <MainRecommendMovies
                    title={val.title}
                    text={val.overview}
                    img_link = {val.backdrop_path}
                    lang="<img src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAwAAAAJCAYAAAAGuM1UAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAC4SURBVHgBlY85DoJQEIb/J5sGXCIgJBJj4R2sTLT1OB7BI3gxl057C2NYBFnksfiklOp900wm883kJ8vtrmbgB2EVRDFmjgm1pNgvFPwjplkOY9xHpyPA9UIQQqBIEqq6gqhpbUGWRXj+u7kasj6nBZ7uC5Y5grletYWyLKGpveaDY+u4PzzUbFYlCaLrrS1MbYMtE8RJCkopJvoQafbBQKjgn85t4bCZgwexa1t8QnC88AkFC8fDF6n6QOQdeN3XAAAAAElFTkSuQmCC' alt='LANGUAGE'>English" id={val.id}
                  />
                </div>
              </>
            ))}
          </Carousel>
        </div>

        <div className="main-filter-bar">
          <div className="filter-bar-title">
            Recommendation
          </div>
          <div className="filter-bar-cards">
              <Slider>
                {!state.result ? "None" : state.result.slice(0,30).reverse().map((v,key) => (
                  <a
                  href={window.location.origin + "/movie/" + v.id}
                  className="blank"
                  >
                     <SmallSearchCard
                        img={v.poster_path}
                        title={v.title}
                        key={key}
                        classn="vertical-card"
                     />
                  </a>
                ))}
              </Slider>
          </div>
        </div>

        <div className="main-filter-bar">
          <div className="filter-bar-title">
            Top Rated
          </div>
          <div className="filter-bar-cards">
              <Slider>
                {!state.result2 ? "None" : state.result2.slice(0,20).map((v,key) => (
                  <a
                  href={window.location.origin + "/movie/" + v.id}
                  className="blank"
                  >
                     <SmallSearchCard
                        img={v.poster_path}
                        title={v.title}
                        key={key}
                        classn="vertical-card"
                     />
                  </a>
                ))}
              </Slider>
          </div>
        </div>

        <div className="main-filter-bar">
          <div className="filter-bar-title">
            Popular Actors
          </div>
          <div className="filter-bar-cards">
              <Slider>
                {!state.result3 ? "None" : state.result3.slice(0,70).map((v,key) => (
                  <a
                  href={window.location.origin + "/person/" + v.id}
                  className="blank"
                  >
                     <SmallSearchCard
                        img={v.profile_path}
                        title={v.name}
                        key={key}
                        classn="vertical-card"
                     />
                  </a>
                ))}
              </Slider>
          </div>
        </div>
      </main>
    </>
  );
}
