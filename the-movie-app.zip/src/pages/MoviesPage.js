const MoviesPage = () => {
  return (
    <h1>MoviesPage</h1>
  )
}

export default MoviesPage;
