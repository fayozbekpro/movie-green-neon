import React from 'react'
import "../../assets/styles/SmallSearchCard.scss"
function Card({img, title, classn}) {
    return (
        <>
            <div className={"sm-search-card " + classn}>
                <div className="img"><img src={"https://image.tmdb.org/t/p/w500/" + img} alt="Img" /></div>
                <div className="datas">{title}</div>
            </div>
        </>
    )
}

export default Card
