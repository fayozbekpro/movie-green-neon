import React from "react";
import "../../assets/styles/MainRecommendMovies.scss";
import parse from "html-react-parser"
function Movies({title, text, lang, id, img_link}) {
  return (
    <>
      <div className="main-recommend-movies">
        <img src={"https://image.tmdb.org/t/p/w500/" + img_link} className="bg-img" alt="" />
        <div className="movies-title">{title.slice(0,40)}</div>
        <div className="text">
          {text.slice(0,250)}...
        </div>
        <div className="lang">{parse(lang)}</div>
        <a href={window.location.origin + "/movie/" + id}>More</a>
      </div>
    </>
  );
}
export default Movies;
